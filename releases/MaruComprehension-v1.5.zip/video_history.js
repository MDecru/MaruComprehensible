// History page — watched videos + unknown word frequency

function _applyTheme(light) {
  document.body.classList.toggle('light-theme', !!light);
}
chrome.storage.local.get('light_theme', ({ light_theme }) => _applyTheme(light_theme));
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.light_theme) _applyTheme(changes.light_theme.newValue);
});

let _videos = {};
let _words  = {};
let _knownWords  = new Set();
let _videoFilter = '';
let _wordFilter  = '';
let _wordSort    = 'count';
let _siteFilter  = null;
let _showKnown   = false;
let _hoverReady  = false;

const $ = id => document.getElementById(id);

async function _load() {
  const data = await chrome.storage.local.get(['mc_video_history', 'mc_word_history', 'mc_user_known']);
  _videos = data.mc_video_history || {};
  _words  = data.mc_word_history  || {};
  _knownWords = new Set(data.mc_user_known || []);
  _renderStats();
  _renderVideos();
  await _renderWords();
  // Activate hover listeners immediately — pre-created .jp-tok spans are already there
  if (!_hoverReady) {
    hoverActivate();
    _hoverReady = true;
  }
}

function _renderStats() {
  const v = Object.keys(_videos).length;
  const w = Object.keys(_words).length;
  $('stats-label').textContent = [
    v ? `${v} video${v === 1 ? '' : 's'}` : '',
    w ? `${w} unknown word${w === 1 ? '' : 's'}` : '',
  ].filter(Boolean).join(' · ');
}

const _SITE_LABELS = { yt: 'YouTube', cij: 'CIJ', njk: 'NJK', player: 'Local' };
const _SITE_ORDER  = ['yt', 'cij', 'njk', 'player'];

function _renderVideos() {
  const q = _videoFilter.trim().toLowerCase();
  let entries = Object.entries(_videos).sort((a, b) => (b[1].lastWatched || 0) - (a[1].lastWatched || 0));

  // Update site filter row (only when multiple sites exist)
  const presentSites = _SITE_ORDER.filter(s => entries.some(([, v]) => (v.site || 'yt') === s));
  const filterRow = $('video-filter-row');
  if (presentSites.length > 1) {
    filterRow.style.display = '';
    filterRow.innerHTML = 'Site: ' + ['all', ...presentSites].map(s =>
      `<button class="sort-btn${(s === 'all' && !_siteFilter) || _siteFilter === s ? ' active' : ''}" data-site="${s}">${s === 'all' ? 'All' : _SITE_LABELS[s]}</button>`
    ).join('');
    filterRow.querySelectorAll('[data-site]').forEach(btn => {
      btn.addEventListener('click', () => {
        _siteFilter = btn.dataset.site === 'all' ? null : btn.dataset.site;
        _renderVideos();
      });
    });
  } else {
    filterRow.style.display = 'none';
    _siteFilter = null;
  }

  if (q) entries = entries.filter(([, v]) => (v.title || '').toLowerCase().includes(q));
  if (_siteFilter) entries = entries.filter(([, v]) => (v.site || 'yt') === _siteFilter);

  $('clear-videos-btn').disabled = !Object.keys(_videos).length;
  const con = $('video-list-container');

  if (!Object.keys(_videos).length) {
    con.innerHTML = `<div class="empty"><strong>No videos yet</strong>Watch a Japanese video with subtitles — the score will be saved here automatically.</div>`;
    return;
  }
  if (!entries.length) {
    const msg = _siteFilter
      ? `No ${_SITE_LABELS[_siteFilter]} videos${q ? ` matching "<strong>${_esc(q)}</strong>"` : ''}`
      : `No videos match "<strong>${_esc(q)}</strong>"`;
    con.innerHTML = `<div class="no-match">${msg}</div>`;
    return;
  }

  con.innerHTML = `<div class="video-list">${entries.map(([key, v]) => {
    const score = v.lastScore?.score;
    const scoreColor = score != null ? _compColor(score) : '#6a7480';
    const siteClass = `site-${v.site || 'yt'}`;
    const siteLabel = v.site === 'cij' ? 'CIJ' : v.site === 'player' ? 'Local' : 'YouTube';
    const date = v.lastWatched ? _fmtDate(v.lastWatched) : '';
    return `<div class="video-card" data-key="${_esc(key)}" data-url="${_esc(v.url || '')}">
      <span class="site-badge ${siteClass}">${siteLabel}</span>
      <div class="video-info">
        <div class="video-title">${_esc(v.title || key)}</div>
        <div class="video-meta">${date}</div>
      </div>
      ${score != null ? `<div class="score-badge" style="color:${scoreColor}">${score}%</div>` : ''}
      ${(v.watchCount || 0) > 1 ? `<div class="watch-count">×${v.watchCount}</div>` : ''}
    </div>`;
  }).join('')}</div>`;

  con.querySelectorAll('.video-card').forEach(card => {
    card.addEventListener('click', () => {
      const url = card.dataset.url;
      if (url && !url.startsWith('blob:')) chrome.tabs.create({ url });
    });
  });
}

function _exportableWords() {
  let entries = Object.entries(_words).sort((a, b) => b[1].count - a[1].count);
  if (!_showKnown) entries = entries.filter(([w]) => !_knownWords.has(w));
  return entries;
}

function _renderWords() {
  const q = _wordFilter.trim().toLowerCase();
  let entries = Object.entries(_words);
  if (_wordSort === 'count') entries.sort((a, b) => b[1].count - a[1].count);
  else entries.sort((a, b) => a[0].localeCompare(b[0], 'ja'));
  if (q) entries = entries.filter(([w]) => w.includes(q) || w.toLowerCase().includes(q));
  if (!_showKnown) entries = entries.filter(([w]) => !_knownWords.has(w));

  const hasWords = !!Object.keys(_words).length;
  const hasExportable = !!_exportableWords().length;
  $('clear-words-btn').disabled  = !hasWords;
  $('export-words-btn').disabled = !hasExportable;
  $('copy-words-btn').disabled   = !hasExportable;
  const con = $('word-list-container');

  if (!Object.keys(_words).length) {
    con.innerHTML = `<div class="empty"><strong>No data yet</strong>Unknown words will appear here as you watch Japanese subtitled videos.</div>`;
    return;
  }
  if (!entries.length) {
    const msg = q
      ? `No words match "<strong>${_esc(q)}</strong>"`
      : `All words are marked as known — click <strong>Show known</strong> to see them`;
    con.innerHTML = `<div class="no-match">${msg}</div>`;
    return;
  }

  con.innerHTML = `<div class="word-list">${entries.map(([w, d]) => {
    const known = _knownWords.has(w);
    const color = known ? '#66AAE8' : '#ED7989';
    return `<div class="word-row">
      <span class="word-text"><span class="jp-tok" data-word="${_esc(w)}" data-basic="${_esc(w)}" data-pos="名詞" data-reading="" style="color:${color};cursor:pointer">${_esc(w)}</span></span>
      <span class="word-count">${d.count}×</span>
      <span class="word-date">${d.lastSeen ? _fmtDate(d.lastSeen) : ''}</span>
    </div>`;
  }).join('')}</div>`;
}

// ── Tab switching ─────────────────────────────────────────────────────────────

$('tab-words-btn').addEventListener('click', () => {
  $('tab-words-btn').classList.add('active');
  $('tab-videos-btn').classList.remove('active');
  $('section-words').style.display = '';
  $('section-videos').style.display = 'none';
});
$('tab-videos-btn').addEventListener('click', () => {
  $('tab-videos-btn').classList.add('active');
  $('tab-words-btn').classList.remove('active');
  $('section-videos').style.display = '';
  $('section-words').style.display = 'none';
});

// ── Sorting ───────────────────────────────────────────────────────────────────

$('sort-count-btn').addEventListener('click', async () => {
  _wordSort = 'count';
  $('sort-count-btn').classList.add('active');
  $('sort-alpha-btn').classList.remove('active');
  await _renderWords();
});
$('sort-alpha-btn').addEventListener('click', async () => {
  _wordSort = 'alpha';
  $('sort-alpha-btn').classList.add('active');
  $('sort-count-btn').classList.remove('active');
  await _renderWords();
});

// ── Search ────────────────────────────────────────────────────────────────────

$('video-search').addEventListener('input', () => { _videoFilter = $('video-search').value; _renderVideos(); });
$('word-search').addEventListener('input', async () => { _wordFilter = $('word-search').value; await _renderWords(); });

// ── Actions ───────────────────────────────────────────────────────────────────

$('clear-videos-btn').addEventListener('click', async () => {
  const n = Object.keys(_videos).length;
  if (!n || !confirm(`Clear all ${n} video history entries?`)) return;
  _videos = {};
  await chrome.storage.local.set({ mc_video_history: {} });
  _renderStats(); _renderVideos();
});

$('clear-words-btn').addEventListener('click', async () => {
  const n = Object.keys(_words).length;
  if (!n || !confirm(`Clear all ${n} unknown word entries?`)) return;
  _words = {};
  await chrome.storage.local.set({ mc_word_history: {} });
  _renderStats(); await _renderWords();
});

$('copy-words-btn').addEventListener('click', async () => {
  const entries = _exportableWords();
  if (!entries.length) return;
  const text = entries.map(([w]) => w).join(', ');
  await navigator.clipboard.writeText(text);
  const btn = $('copy-words-btn');
  const prev = btn.textContent;
  btn.textContent = 'Copied!';
  setTimeout(() => { btn.textContent = prev; }, 1500);
});

$('export-words-btn').addEventListener('click', () => {
  const entries = _exportableWords();
  if (!entries.length) return;
  const csv = 'word,count,last_seen\n' + entries.map(([w, d]) =>
    `"${w.replace(/"/g,'""')}",${d.count},${d.lastSeen ? new Date(d.lastSeen).toISOString().split('T')[0] : ''}`
  ).join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
  a.download = 'unknown_words.csv';
  a.click();
  URL.revokeObjectURL(a.href);
});

$('show-known-btn').addEventListener('click', () => {
  _showKnown = !_showKnown;
  $('show-known-btn').classList.toggle('active', _showKnown);
  _renderWords();
});

document.addEventListener('mc-word-marked-known', e => {
  _knownWords.add(e.detail.word);
  if (!_showKnown) _renderWords();
});

// ── Helpers ───────────────────────────────────────────────────────────────────

function _esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function _fmtDate(ts) {
  return new Date(ts).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

function _compColor(score) {
  const stops = [[237,121,137],[253,194,129],[114,206,157]];
  const t = Math.max(0, Math.min(100, score)) / 100;
  const seg = t < 0.5 ? 0 : 1;
  const lt  = t < 0.5 ? t * 2 : (t - 0.5) * 2;
  const [r1,g1,b1] = stops[seg], [r2,g2,b2] = stops[seg+1];
  return `rgb(${Math.round(r1+(r2-r1)*lt)},${Math.round(g1+(g2-g1)*lt)},${Math.round(b1+(b2-b1)*lt)})`;
}

_load();
