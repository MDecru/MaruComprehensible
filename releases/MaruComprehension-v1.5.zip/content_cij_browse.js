// Badge injector for CIJ listing pages (not video pages — those use content_cij.js)
(async () => {
  if (/\/video\/\d/.test(location.pathname)) return;

  const { mc_history_enabled = true, mc_badges_enabled = true, mc_video_history = {} } =
    await chrome.storage.local.get(['mc_history_enabled', 'mc_badges_enabled', 'mc_video_history']);
  if (!mc_history_enabled || !mc_badges_enabled || !Object.keys(mc_video_history).length) return;

  function _color(score) {
    if (score == null) return '#72CE9D';
    const stops = [[237,121,137],[253,194,129],[114,206,157]];
    const t = Math.max(0, Math.min(100, score)) / 100;
    const seg = t < 0.5 ? 0 : 1;
    const lt  = t < 0.5 ? t * 2 : (t - 0.5) * 2;
    const [r1,g1,b1] = stops[seg], [r2,g2,b2] = stops[seg+1];
    return `rgb(${Math.round(r1+(r2-r1)*lt)},${Math.round(g1+(g2-g1)*lt)},${Math.round(b1+(b2-b1)*lt)})`;
  }

  function _inject() {
    document.querySelectorAll('a:not([data-mc-cij-chk])').forEach(a => {
      a.dataset.mcCijChk = '1';
      const m = a.href.match(/\/video\/(\d+)/);
      if (!m) return;
      const entry = mc_video_history[`cij_${m[1]}`];
      if (!entry) return;

      const score = entry.lastScore?.score;
      const badge = document.createElement('div');
      badge.className = 'mc-watched-badge';
      badge.style.cssText = [
        'position:absolute', 'bottom:8px', 'left:8px', 'z-index:10',
        'background:rgba(0,0,0,.85)', `color:${_color(score)}`,
        'font:700 13px/1 -apple-system,sans-serif',
        'padding:5px 10px', 'border-radius:6px', 'pointer-events:none',
        'letter-spacing:.3px',
      ].join(';');
      badge.textContent = score != null ? `✓ ${score}%` : '✓ Watched';

      if (!a.style.position) a.style.position = 'relative';
      a.appendChild(badge);
    });
  }

  let _cijTimer = null;
  _inject();
  // This content script matches the whole cijapanese.com origin, so it also runs on
  // non-HTML responses (sitemap.xml, JSON endpoints, etc.) that Chrome's built-in
  // viewer renders without a <body> — guard against that instead of crashing.
  const observer = new MutationObserver(() => { clearTimeout(_cijTimer); _cijTimer = setTimeout(_inject, 250); });
  if (document.body) observer.observe(document.body, { childList: true, subtree: true });
  else document.addEventListener('DOMContentLoaded', () => {
    if (document.body) observer.observe(document.body, { childList: true, subtree: true });
  }, { once: true });
})();
