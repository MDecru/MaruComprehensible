// Sidebar — unknown words grouped by JLPT level.
// Depends on: common.js (buildMergedTokens, getTokenizer, getVocab, MM_CONTENT_POS, hasKanji)
//             hover.js (_katToHira, _hoverJlptMap)

var _sidebarEl = null;
var _sbPrevBodyMargin = '';
var _sbPushFn = null;
var _sbPopFn  = null;
var _sbLastGroups = null;

// Site content scripts can register custom push/restore handlers when body
// marginRight doesn't work (e.g. YouTube, NJK where body overflow is hidden).
function sbRegisterPush(pushFn, popFn) { _sbPushFn = pushFn; _sbPopFn = popFn; }
var _sbSortMode = 'jlpt';   // 'jlpt' | 'freq'
var _sbActiveFilter = 'unknown';
var _sbViewMode = 'words';  // 'words' | 'kanji' | 'grammar'
var _sbLastKanjiGroups = null;
var _sbLastGrammarGroups = null;

function sidebarIsOpen() { return _sidebarEl !== null; }

// Accepts either a plain transcript string (no per-line timing, e.g. NJK scraped
// pages) or an array of timed cues from mcParseVTTCues (e.g. YouTube/CIJ/player —
// lets grammar-point examples link back to the moment they occur in the video).
async function sidebarToggle(input) {
  if (_sidebarEl) { _sidebarClose(); return { ok: true, closed: true }; }
  // Dismiss any pinned hover tooltip so it doesn't overlap the sidebar
  if (typeof _hoverHide === 'function') _hoverHide();
  const cues = Array.isArray(input) ? input : (input?.trim() ? [{ start: null, text: input }] : null);
  if (!cues || !cues.length) return { ok: false, error: 'No text available' };

  let tokenizer;
  try { tokenizer = await getTokenizer(); }
  catch { return { ok: false, error: 'Tokenizer not ready — pre-load first' }; }

  const [vocab, jlptMap, jlptVocab, { light_theme }, kanjiKnownSet] = await Promise.all([
    getVocab(),
    _sbLoadJlptMap(),
    _sbLoadJlptVocab(),
    new Promise(r => chrome.storage.local.get('light_theme', r)),
    getKanji(),
  ]);

  // Tokenize per cue (rather than one big joined blob) so each token can carry
  // the cue's start time — the rare compound that straddles a cue boundary
  // won't merge, which is an acceptable trade for accurate timestamps.
  const tokens = [];
  const tokenTime = []; // parallel array: cue start ms (or null) for tokens[i]
  for (const cue of cues) {
    if (!cue.text?.trim()) continue;
    for (const tok of buildMergedTokens(tokenizer.tokenize(cue.text), vocab)) {
      tokens.push(tok);
      tokenTime.push(cue.start ?? null);
    }
  }

  // Collect all unique content words (known and unknown). Uses MM_TAGGABLE_POS
  // (not MM_CONTENT_POS) so discourse connectors like そして show up here too —
  // doesn't touch the separate score%/known-word-count math in common.js.
  const seen = new Map();
  for (const tok of tokens) {
    if (!MM_TAGGABLE_POS.has(tok.pos)) continue;
    const w = tok.basic_form || tok.surface_form;
    if (!hasKanji(w) && [...w].length < 2) continue;

    const known = vocab.has(w) || vocab.has(tok.surface_form) || _allKanjiKnown(w, kanjiKnownSet) || _stemKnown(w, vocab) || _stemKnown(tok.surface_form, vocab);
    if (!seen.has(w)) {
      // Bunpro JLPT vocab list, fallback to hardest kanji level
      const level = _sbWordJlpt(w, jlptMap, jlptVocab);
      seen.set(w, { basic: w, reading: _katToHira(tok.reading || ''), level, known, count: 0 });
    }
    seen.get(w).count++;
  }

  // Load MaruMori word-level info for badges
  let mmStatusMap = new Map();
  try { mmStatusMap = await getWordStatusMap(); } catch {}

  const groups = { 5: [], 4: [], 3: [], 2: [], 1: [], 0: [] };
  for (const entry of seen.values()) {
    const mm = mmStatusMap.get(entry.basic);
    if (mm) { entry.mmLevel = mm.level; entry.mmStatus = mm.status; }
    groups[entry.level].push(entry);
  }

  // Collect unique kanji from content tokens
  const kanjiSeen = new Map();
  for (const tok of tokens) {
    if (!MM_CONTENT_POS.has(tok.pos)) continue;
    const w = tok.basic_form || tok.surface_form;
    for (const ch of w) {
      if (!/[一-龯㐀-䶿]/.test(ch)) continue;
      if (!kanjiSeen.has(ch)) {
        const lvl = jlptMap[ch] || 0;
        kanjiSeen.set(ch, { basic: ch, reading: '', level: lvl, known: kanjiKnownSet.has(ch), count: 0 });
      }
      kanjiSeen.get(ch).count++;
    }
  }
  const kanjiGroups = { 5: [], 4: [], 3: [], 2: [], 1: [], 0: [] };
  for (const entry of kanjiSeen.values()) kanjiGroups[entry.level].push(entry);

  // Collect grammar points (conjugation forms + particle roles) tagged during merge.
  // Each example keeps the timestamp (ms) of the cue it came from, if any, so the
  // sidebar can seek the video there on click.
  const grammarSeen = new Map(); // tag → { tag, desc, count, examples: [{surface, time}] }
  for (let i = 0; i < tokens.length; i++) {
    const tok = tokens[i];
    if (!tok.conj || !tok.conj.length) continue;
    const time = tokenTime[i];
    for (const tag of tok.conj) {
      if (!grammarSeen.has(tag)) grammarSeen.set(tag, { tag, desc: CONJ_TAG_INFO[tag] || '', count: 0, examples: [] });
      const g = grammarSeen.get(tag);
      g.count++;
      if (g.examples.length < 6 && !g.examples.some(e => e.surface === tok.surface_form)) {
        g.examples.push({ surface: tok.surface_form, time });
      }
    }
  }
  const grammarGroups = { conj: [], particle: [], connector: [] };
  for (const g of grammarSeen.values()) {
    const bucket = CONJ_DISCOURSE_LABELS.has(g.tag) ? 'connector' : CONJ_PARTICLE_LABELS.has(g.tag) ? 'particle' : 'conj';
    grammarGroups[bucket].push(g);
  }
  grammarGroups.conj.sort((a, b) => b.count - a.count);
  grammarGroups.particle.sort((a, b) => b.count - a.count);
  grammarGroups.connector.sort((a, b) => b.count - a.count);

  _sidebarInject(groups, kanjiGroups, grammarGroups, !!light_theme);
  return { ok: true };
}

function _sidebarClose() {
  _sidebarEl?.remove();
  _sidebarEl = null;
  if (_sbPopFn) {
    _sbPopFn();
  } else {
    document.body.style.transition = 'margin-right .2s ease';
    document.body.style.marginRight = _sbPrevBodyMargin;
  }
}

async function _sbLoadJlptMap() {
  // Reuse map already loaded by hover.js if available
  if (window._jlptMapCache) return window._jlptMapCache;
  if (_hoverJlptMap && Object.keys(_hoverJlptMap).length) {
    window._jlptMapCache = _hoverJlptMap;
    return _hoverJlptMap;
  }
  try {
    const r = await fetch(chrome.runtime.getURL('data/jlpt_mapping.json'));
    const data = await r.json();
    const map = {};
    for (const [lvl, ks] of Object.entries(data)) for (const k of ks) map[k] = +lvl;
    window._jlptMapCache = map;
    _hoverJlptMap = map;
    return map;
  } catch { return {}; }
}

// Comprehensive JLPT vocab lookup (Bunpro + kanji-derived + readings, 361k keys)
var _sbJlptVocab = null;
async function _sbLoadJlptVocab() {
  if (_sbJlptVocab) return _sbJlptVocab;
  try {
    const r = await fetch(chrome.runtime.getURL('data/jlpt_vocab_lookup.json'));
    _sbJlptVocab = await r.json();
    return _sbJlptVocab;
  } catch { _sbJlptVocab = {}; return {}; }
}

function _allKanjiKnown(word, kanjiSet) {
  if (!kanjiSet || !kanjiSet.size) return false;
  var hasKanji = false;
  for (var i = 0; i < word.length; i++) {
    if (/[一-龯㐀-䶿]/.test(word[i])) { hasKanji = true; if (!kanjiSet.has(word[i])) return false; }
  }
  return hasKanji;
}
function _stemKnown(word, vocab) {
  var m = word.match(/^(.+)(する|される|させる|できる|出来る|なさる|致す|いたす)$/);
  if (m && vocab.has(m[1])) return true;
  m = word.match(/^(.+)(に|な|だ)$/);
  if (m && vocab.has(m[1])) return true;
  m = word.match(/^(.+)(ている|てる|でいる|でる)$/);
  if (m && vocab.has(m[1])) return true;
  return false;
}

function _sbWordJlpt(w, jlptMap, jlptVocab) {
  // First try Bunpro JLPT vocab list (proper source)
  if (jlptVocab[w]) return jlptVocab[w];
  // Fallback: hardest kanji level
  let level = 0;
  for (var i = 0; i < w.length; i++) {
    var l = jlptMap[w[i]];
    if (l && (level === 0 || l < level)) level = l;
  }
  return level;
}

var _SB_LABEL = { 1:'N1', 2:'N2', 3:'N3', 4:'N4', 5:'N5', 0:'Other' };
var _SB_COLOR = { 5:'#ED7989', 4:'#FDC281', 3:'#72CE9D', 2:'#66AAE8', 1:'#7E69F0', 0:'#555a65' };

function _sbHex2rgb(hex) {
  return [1,3,5].map(i => parseInt(hex.slice(i, i+2), 16)).join(',');
}

function _sbEsc(s) {
  return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function _sbWordHtml(w, wordCol, dimColor, readingColor) {
  const reading = (w.reading && w.reading !== w.basic)
    ? `<span class="sb-r">${_sbEsc(w.reading)}</span>` : '';
  const count = w.count > 1 ? `<span class="sb-x">×${w.count}</span>` : '';
  const cls   = `sb-word${w.known ? ' sb-known' : ' sb-unknown'}`;
  const mmBadge = w.mmLevel != null
    ? `<span class="sb-mmlv">${_sbEsc(String(w.mmLevel))}</span>` : '';
  return `<div class="${cls}" data-basic="${_sbEsc(w.basic)}" data-reading="${_sbEsc(w.reading)}" style="--c:${wordCol}">
    <span class="sb-s">${_sbEsc(w.basic)}</span>${mmBadge}${reading}${count}
  </div>`;
}

function _sbBuildSections(groups, isLight, sortMode) {
  const empty = '<div style="padding:28px 14px;color:#4a5068;font-size:12px;text-align:center">No words found</div>';

  if (sortMode === 'freq') {
    const allWords = Object.entries(groups).flatMap(([lvl, ws]) =>
      ws.map(w => ({ ...w, lvl: +lvl }))
    ).sort((a, b) => b.count - a.count);
    if (!allWords.length) return empty;
    const wUnk = allWords.filter(w => !w.known).length;
    const wKnw = allWords.filter(w =>  w.known).length;
    const wordsHtml = allWords.map(w => {
      const col = (w.lvl === 0 && !isLight) ? '#c8cedd' : _SB_COLOR[w.lvl];
      return _sbWordHtml(w, col);
    }).join('');
    return `<div class="sb-sec" data-unk="${wUnk}" data-knw="${wKnw}">
      <div class="sb-sh">
        <span class="sb-n sb-n-unk">${wUnk} unknown</span>
        <span class="sb-n sb-n-knw" style="display:none">${wKnw} known</span>
        <span class="sb-n sb-n-all" style="display:none">${allWords.length} words</span>
        <button class="sb-tog" title="Collapse section">−</button>
      </div>
      <div class="sb-ws">${wordsHtml}</div>
    </div>`;
  }

  // JLPT grouped view
  let html = '';
  for (const lvl of [5, 4, 3, 2, 1, 0]) {
    const words = groups[lvl];
    if (!words.length) continue;
    const col     = _SB_COLOR[lvl];
    const wordCol = (lvl === 0 && !isLight) ? '#c8cedd' : col;
    const label   = _SB_LABEL[lvl];
    const rgb     = _sbHex2rgb(col);
    const wUnk    = words.filter(w => !w.known).length;
    const wKnw    = words.filter(w =>  w.known).length;
    const wordsHtml = words.map(w => _sbWordHtml(w, wordCol)).join('');
    html += `<div class="sb-sec" data-unk="${wUnk}" data-knw="${wKnw}">
      <div class="sb-sh">
        <span class="sb-badge" style="color:${col};border-color:rgba(${rgb},.35);background:rgba(${rgb},.12)">${label}</span>
        <span class="sb-n sb-n-unk">${wUnk} unknown</span>
        <span class="sb-n sb-n-knw" style="display:none">${wKnw} known</span>
        <span class="sb-n sb-n-all" style="display:none">${words.length} word${words.length !== 1 ? 's' : ''}</span>
        <button class="sb-tog" title="Collapse section">−</button>
      </div>
      <div class="sb-ws">${wordsHtml}</div>
    </div>`;
  }
  return html || empty;
}

function _sbFmtTime(ms) {
  const s = Math.floor(ms / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

function _sbGrammarItemHtml(g) {
  const exHtml = g.examples.length
    ? `<div class="sb-gram-ex">${g.examples.map(e => {
        const clickable = e.time != null;
        const cls   = clickable ? 'sb-gram-ex-item sb-gram-ex-link' : 'sb-gram-ex-item';
        const attrs = clickable ? ` data-time="${e.time}" title="Jump to ${_sbFmtTime(e.time)}"` : '';
        return `<span class="${cls}"${attrs}>${_sbEsc(e.surface)}</span>`;
      }).join('<span class="sb-gram-ex-sep">、</span>')}</div>`
    : '';
  const mmUrl = `https://marumori.io/grammar?q=${encodeURIComponent(CONJ_LABEL_TO_SURFACE[g.tag] || g.tag)}`;
  return `<div class="sb-gram">
    <div class="sb-gram-top">
      <a class="sb-gram-tag" href="${mmUrl}" target="_blank" title="Look up on MaruMori">${_sbEsc(g.tag)}</a>
      <span class="sb-x">×${g.count}</span>
    </div>
    <div class="sb-gram-desc">${_sbEsc(g.desc)}</div>
    ${exHtml}
  </div>`;
}

function _sbGrammarTotal(g) {
  return (g.conj?.length || 0) + (g.particle?.length || 0) + (g.connector?.length || 0);
}

function _sbGrammarSectionHtml(label, color, items, unit) {
  if (!items.length) return '';
  return `<div class="sb-sec">
    <div class="sb-sh">
      <span class="sb-badge" style="color:#fff;background:${color};border:none">${label}</span>
      <span class="sb-n sb-n-all">${items.length} ${unit}${items.length !== 1 ? 's' : ''}</span>
      <button class="sb-tog" title="Collapse section">−</button>
    </div>
    <div class="sb-ws">${items.map(_sbGrammarItemHtml).join('')}</div>
  </div>`;
}

function _sbBuildGrammarSections(grammarGroups) {
  const empty = '<div style="padding:28px 14px;color:#4a5068;font-size:12px;text-align:center">No grammar points detected</div>';
  const { conj = [], particle = [], connector = [] } = grammarGroups || {};
  if (!conj.length && !particle.length && !connector.length) return empty;

  return _sbGrammarSectionHtml('Conjugation', '#7E69F0', conj, 'form')
    + _sbGrammarSectionHtml('Particle roles', '#66AAE8', particle, 'role')
    + _sbGrammarSectionHtml('Connectors', '#72CE9D', connector, 'connector');
}

function _sidebarInject(groups, kanjiGroups, grammarGroups, isLight = false) {
  _sbLastGroups = groups;
  _sbLastKanjiGroups = kanjiGroups;
  _sbLastGrammarGroups = grammarGroups || { conj: [], particle: [], connector: [] };
  _sidebarClose();

  // Theme tokens
  const T = isLight ? {
    bg:         '#ffffff',
    surface:    '#f0f2f5',
    border:     '#66AAE8',
    text:       '#2c2f33',
    body:       '#3a3f47',
    muted:      '#66748a',
    dim:        '#8896a8',
    ftabBg:     '#66AAE8',
    ftabColor:  '#fff',
    wordHover:  'rgba(102,170,232,.08)',
    reading:    '#66AAE8',
    closeColor: '#7E69F0',
    closeHover: '#5a4bc8',
  } : {
    bg:         '#232425',
    surface:    '#2D3031',
    border:     '#363A3B',
    text:       '#f0f2f8',
    body:       '#d4d8e8',
    muted:      '#9aa3bc',
    dim:        '#5a6282',
    ftabBg:     '#72CE9D',
    ftabColor:  '#fff',
    wordHover:  'rgba(255,255,255,.05)',
    reading:    '#66AAE8',
    closeColor: '#4a5068',
    closeHover: '#e8eaf0',
  };

  const allWords = Object.values(groups).flat();
  const unknownCount = allWords.filter(w => !w.known).length;
  const knownCount   = allWords.filter(w =>  w.known).length;
  const allKanji = Object.values(kanjiGroups).flat();
  const kanjiUnk = allKanji.filter(k => !k.known).length;
  const kanjiKnw = allKanji.filter(k =>  k.known).length;
  const grammarCount = _sbGrammarTotal(_sbLastGrammarGroups);

  const el = document.createElement('div');
  el.id = 'jp-sidebar';
  el.innerHTML = `<style>
    #jp-sidebar{position:fixed;top:0;right:0;width:260px;height:100vh;
      background:${T.bg};border-left:1px solid ${T.border};
      font-family:-apple-system,BlinkMacSystemFont,'Segoe UI Variable Text','Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;
      z-index:2147483646;overflow-y:auto;
      box-shadow:-6px 0 24px rgba(0,0,0,.4);color:${T.body};font-size:13px}
    #jp-sb-hd{display:flex;align-items:center;padding:13px 14px 11px;
      border-bottom:1px solid ${T.border};position:sticky;top:0;background:${T.bg};z-index:1;
      flex-wrap:wrap;gap:6px 0}
    #jp-sb-top{display:flex;align-items:center;width:100%}
    #jp-sb-stats{display:flex;flex-direction:column;gap:2px;font-size:11px;color:${T.dim};width:100%;margin-top:3px}
    #jp-sb-ttl{font-size:13px;font-weight:700;color:${T.text};letter-spacing:.3px}
    #jp-sb-tot{font-size:11px;color:${T.dim}}
    #jp-sb-cls{margin-left:auto;background:none;border:none;color:${T.closeColor};
      font-size:18px;cursor:pointer;line-height:1;padding:0 2px}
    #jp-sb-cls:hover{color:${T.closeHover}}
    #jp-sb-view{display:flex;align-items:center;gap:4px;width:100%;flex-wrap:wrap}
    #jp-sb-controls{display:flex;align-items:center;gap:4px;margin-left:auto}
    .sb-vtab{background:rgba(128,128,128,.08);border:1px solid rgba(128,128,128,.2);
      border-radius:12px;color:${T.muted};font-size:11px;font-weight:600;
      padding:3px 11px;cursor:pointer;transition:all .12s}
    .sb-vtab:hover{background:rgba(128,128,128,.14);color:${T.body}}
    .sb-vtab.active{background:${T.ftabBg};border-color:${T.ftabBg};color:${T.ftabColor}}
    .sb-ftab{background:rgba(128,128,128,.08);border:1px solid rgba(128,128,128,.2);
      border-radius:12px;color:${T.muted};font-size:10.5px;font-weight:600;
      padding:2px 8px;cursor:pointer;transition:all .12s}
    .sb-ftab:hover{background:rgba(128,128,128,.14);color:${T.body}}
    .sb-ftab.active{background:${T.ftabBg};border-color:${T.ftabBg};color:${T.ftabColor}}
    .sb-sec{border-top:1px solid ${T.border}}
    .sb-sec.sb-collapsed .sb-ws{display:none}
    .sb-sh{display:flex;align-items:center;gap:8px;padding:9px 14px 5px;cursor:pointer;
      user-select:none}
    .sb-sh:hover{background:rgba(128,128,128,.05)}
    .sb-badge{font-size:11px;font-weight:700;border-radius:5px;padding:2px 8px;border:1px solid}
    .sb-n{font-size:11px;color:${T.dim}}
    .sb-tog{margin-left:auto;background:none;border:none;color:${T.dim};cursor:pointer;
      font-size:14px;line-height:1;padding:0 2px}
    .sb-tog:hover{color:${T.body}}
    .sb-ws{padding:2px 0 6px}
    .sb-word{display:flex;align-items:baseline;gap:5px;padding:5px 14px;
      color:${T.body};cursor:pointer;transition:background .1s}
    .sb-word:hover{background:${T.wordHover}}
    .sb-s{font-size:15px;font-weight:600;color:var(--c)}
    .sb-mmlv{font-size:9px;font-weight:700;padding:1px 4px;border-radius:4px;
      margin-left:4px;vertical-align:middle;position:relative;top:-1px;
      background:rgba(102,170,232,.2);color:#66AAE8}
    .sb-r{font-size:11px;color:${T.reading}}
    .sb-x{margin-left:auto;font-size:10px;color:${T.dim}}
    .sb-gram{padding:8px 14px;border-top:1px solid ${T.border}}
    .sb-gram:first-child{border-top:none}
    .sb-gram-top{display:flex;align-items:center;gap:6px}
    .sb-gram-tag{font-size:11px;font-weight:700;color:#fff;background:#E5484D;border:none;
      border-radius:9px;padding:2px 8px;text-decoration:none;cursor:pointer}
    .sb-gram-tag:hover{filter:brightness(1.1)}
    .sb-gram-desc{font-size:12px;color:${T.body};line-height:1.4;margin-top:5px}
    .sb-gram-ex{font-size:12px;color:${T.muted};margin-top:4px;line-height:1.5}
    .sb-gram-ex-sep{color:${T.dim}}
    .sb-gram-ex-link{color:${T.reading};cursor:pointer;border-bottom:1px dotted currentColor}
    .sb-gram-ex-link:hover{color:${isLight ? '#1a5fa8' : '#8ec3f2'}}
    #jp-sidebar.filter-unknown .sb-known{display:none}
    #jp-sidebar.filter-known  .sb-unknown{display:none}
    #jp-sidebar.filter-unknown .sb-sec[data-unk="0"],
    #jp-sidebar.filter-known  .sb-sec[data-knw="0"]{display:none}
  </style>
  <div id="jp-sb-hd">
    <div id="jp-sb-top">
      <span id="jp-sb-ttl">${_sbViewMode === 'kanji' ? 'Kanji' : _sbViewMode === 'grammar' ? 'Grammar' : 'Words'}</span>
      <button id="jp-sb-cls">×</button>
    </div>
    <div id="jp-sb-stats">
      <span id="jp-sb-tot">${allWords.length} words · ${allKanji.length} kanji · ${grammarCount} grammar</span>
    </div>
    <div id="jp-sb-view">
      <button class="sb-vtab${_sbViewMode === 'words' ? ' active' : ''}" data-view="words">Words</button>
      <button class="sb-vtab${_sbViewMode === 'kanji' ? ' active' : ''}" data-view="kanji">Kanji</button>
      <button class="sb-vtab${_sbViewMode === 'grammar' ? ' active' : ''}" data-view="grammar">Grammar</button>
      <span id="jp-sb-controls" style="display:${_sbViewMode === 'grammar' ? 'none' : 'flex'};margin-left:auto;gap:4px;align-items:center">
        <button class="sb-ftab active" data-filter="unknown">Unknown</button>
        <button class="sb-ftab" data-filter="">All</button>
        <button class="sb-ftab" data-filter="known">Known</button>
        <button class="sb-ftab${_sbSortMode === 'freq' ? ' active' : ''}" id="jp-sb-sort">⇅</button>
      </span>
    </div>
  </div>
  <div id="jp-sb-body">${
    _sbViewMode === 'grammar' ? _sbBuildGrammarSections(grammarGroups)
    : _sbBuildSections(_sbViewMode === 'kanji' ? kanjiGroups : groups, isLight, _sbSortMode)
  }</div>`;

  // Push page content left so sidebar doesn't overlay it
  if (_sbPushFn) {
    _sbPushFn();
  } else {
    _sbPrevBodyMargin = document.body.style.marginRight;
    document.body.style.transition = 'margin-right .2s ease';
    document.body.style.marginRight = '260px';
  }

  document.body.appendChild(el);
  _sidebarEl = el;

  // Start with saved filter active
  el.classList.add(_sbActiveFilter ? `filter-${_sbActiveFilter}` : '');
  _sbUpdateSectionCounts(el, _sbActiveFilter);

  el.querySelector('#jp-sb-cls').addEventListener('click', _sidebarClose);

  // Filter tabs
  const controlsEl = el.querySelector('#jp-sb-controls');
  if (controlsEl) controlsEl.addEventListener('click', e => {
    const tab = e.target.closest('.sb-ftab');
    if (!tab || tab.id === 'jp-sb-sort') return;
    el.querySelectorAll('#jp-sb-controls .sb-ftab[data-filter]').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const f = tab.dataset.filter;
    _sbActiveFilter = f;
    el.classList.toggle('filter-unknown', f === 'unknown');
    el.classList.toggle('filter-known',   f === 'known');
    _sbUpdateSectionCounts(el, f);
  });

  // View toggle (Words / Kanji / Grammar)
  el.querySelector('#jp-sb-view').addEventListener('click', e => {
    const vtab = e.target.closest('.sb-vtab');
    if (!vtab) return;
    el.querySelectorAll('.sb-vtab').forEach(t => t.classList.remove('active'));
    vtab.classList.add('active');
    _sbViewMode = vtab.dataset.view;

    const isGrammar = _sbViewMode === 'grammar';
    const isKanji   = _sbViewMode === 'kanji';
    el.querySelector('#jp-sb-ttl').textContent = isGrammar ? 'Grammar' : isKanji ? 'Kanji' : 'Words';
    const ctrl = el.querySelector('#jp-sb-controls');
    if (ctrl) ctrl.style.display = isGrammar ? 'none' : 'flex';

    if (isGrammar) {
      el.querySelector('#jp-sb-body').innerHTML = _sbBuildGrammarSections(_sbLastGrammarGroups);
      return;
    }
    const activeGroups = isKanji ? _sbLastKanjiGroups : _sbLastGroups;
    el.querySelector('#jp-sb-body').innerHTML = _sbBuildSections(activeGroups, isLight, _sbSortMode);
    _sbUpdateSectionCounts(el, _sbActiveFilter);
  });

  // Sort toggle
  el.querySelector('#jp-sb-sort').addEventListener('click', e => {
    _sbSortMode = _sbSortMode === 'freq' ? 'jlpt' : 'freq';
    e.currentTarget.classList.toggle('active', _sbSortMode === 'freq');
    const activeGroups = _sbViewMode === 'kanji' ? _sbLastKanjiGroups : _sbLastGroups;
    el.querySelector('#jp-sb-body').innerHTML = _sbBuildSections(activeGroups, isLight, _sbSortMode);
    _sbUpdateSectionCounts(el, _sbActiveFilter);
  });

  // Collapse/expand sections via header click or toggle button
  el.addEventListener('click', e => {
    const sh = e.target.closest('.sb-sh');
    if (!sh) return;
    // Don't collapse if clicking on the word itself (sb-word is a child of sb-ws, not sb-sh)
    const sec = sh.closest('.sb-sec');
    if (!sec) return;
    sec.classList.toggle('sb-collapsed');
    const tog = sh.querySelector('.sb-tog');
    if (tog) tog.textContent = sec.classList.contains('sb-collapsed') ? '+' : '−';
  });

  // Word clicks — open hover tooltip
  el.addEventListener('click', e => {
    const word = e.target.closest('.sb-word');
    if (!word) return;
    hoverShowWord({ basic: word.dataset.basic, reading: word.dataset.reading }, word);
  });

  // Grammar example clicks — seek the video to where that example occurs
  el.addEventListener('click', e => {
    const ex = e.target.closest('.sb-gram-ex-link');
    if (!ex) return;
    const t = +ex.dataset.time;
    const video = document.querySelector('video');
    if (video && !isNaN(t)) video.currentTime = t / 1000;
  });
}

function _sbUpdateSectionCounts(el, filter) {
  for (const sec of el.querySelectorAll('.sb-sec')) {
    const unk = sec.querySelector('.sb-n-unk'), knw = sec.querySelector('.sb-n-knw'), all = sec.querySelector('.sb-n-all');
    if (unk) unk.style.display = filter === 'unknown' ? '' : 'none';
    if (knw) knw.style.display = filter === 'known'   ? '' : 'none';
    if (all) all.style.display = (filter === '' || !unk) ? '' : 'none';
  }
}

// Re-inject with new theme when the popup toggle changes
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && 'light_theme' in changes && _sidebarEl && _sbLastGroups) {
    _sidebarInject(_sbLastGroups, _sbLastKanjiGroups || { 5:[], 4:[], 3:[], 2:[], 1:[], 0:[] }, _sbLastGrammarGroups || { conj: [], particle: [], connector: [] }, !!changes.light_theme.newValue);
  }
});
