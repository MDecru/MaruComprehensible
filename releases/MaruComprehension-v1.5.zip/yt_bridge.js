// Runs in the PAGE'S main world (world: "MAIN") so it can access page globals
// and intercept network requests.

let _cachedJaTracks = null;
let _cachedCaptions = []; // {lang, kind, text} — filled by XHR/fetch intercept
// Once a SPA navigation has been observed (via the /youtubei/v1/player fetch
// below), window.ytInitialPlayerResponse is frozen at whatever video loaded
// the page and can no longer be trusted — _cachedJaTracks becomes the only
// source of truth from that point on, even when it's legitimately empty.
let _navigated = false;

// Extract Japanese tracks from any playerCaptionsTracklistRenderer object.
function _jaTracksFrom(data) {
  const all = data?.captions?.playerCaptionsTracklistRenderer?.captionTracks || [];
  return all
    .filter(t => /^ja/i.test(t.languageCode) && t.baseUrl)
    .map(t => ({ baseUrl: t.baseUrl, languageCode: t.languageCode, kind: t.kind || '' }));
}

// Parse a timedtext type=list XML response into our track shape.
function _jaTracksFromListXml(xml, videoId) {
  const tracks = [];
  for (const m of xml.matchAll(/<track\b([^>]*)>/g)) {
    const attrs = m[1];
    const langCode = attrs.match(/lang_code="([^"]*)"/)?.[1] || '';
    if (!/^ja/i.test(langCode)) continue;
    const name = attrs.match(/\bname="([^"]*)"/)?.[1] || '';
    const kind = attrs.match(/\bkind="([^"]*)"/)?.[1] || '';
    tracks.push({
      baseUrl: `https://www.youtube.com/api/timedtext?v=${videoId}&lang=${langCode}&name=${encodeURIComponent(name)}`,
      languageCode: langCode, kind,
    });
  }
  return tracks;
}

// Primary reset trigger: YouTube's own SPA-navigation event, dispatched on
// `document` in every world. The /youtubei/v1/player fetch intercept below
// is not a reliable substitute — YouTube doesn't always re-issue that exact
// request on every client-side navigation, so _cachedCaptions is cleared
// unconditionally here to stop it serving a previous video's real caption
// text under a new video's id. _cachedJaTracks, however, can't just be
// nulled the same way: nothing then reliably repopulates it if this nav
// never triggers a fresh /youtubei/v1/player call (common on related-video
// clicks), permanently starving fetchJaVTT's "is this a manual track"
// check. So actively re-fetch the track list ourselves, scoped to the new
// video id, instead of passively waiting to intercept one.
document.addEventListener('yt-navigate-finish', () => {
  _cachedCaptions = [];
  _navigated = true;
  const videoId = new URLSearchParams(location.search).get('v');
  if (!videoId) { _cachedJaTracks = []; return; }
  _origFetch(`https://www.youtube.com/api/timedtext?v=${videoId}&type=list`)
    .then(r => r.text())
    .then(xml => { _cachedJaTracks = _jaTracksFromListXml(xml, videoId); })
    .catch(() => { _cachedJaTracks = []; });
});

// Seed from the initial page load value (hard navigation).
_cachedJaTracks = _jaTracksFrom(window.ytInitialPlayerResponse);

// --- XHR interception ---
// YouTube player uses XHR (not fetch) for captions, so our window.fetch override
// never sees them. Intercept XHR to cache caption text as the player fetches it.
const _OrigXHROpen = XMLHttpRequest.prototype.open;
const _OrigXHRSend = XMLHttpRequest.prototype.send;
XMLHttpRequest.prototype.open = function(method, url, ...args) {
  if (typeof url === 'string') this._mcUrl = url;
  return _OrigXHROpen.apply(this, [method, url, ...args]);
};
XMLHttpRequest.prototype.send = function(...args) {
  if (this._mcUrl?.includes('api/timedtext')) {
    const mcUrl = this._mcUrl;
    this.addEventListener('load', function() {
      if (this.status === 200 && this.responseText?.length > 0) {
        try {
          const u = new URL(mcUrl, location.href);
          const lang = u.searchParams.get('lang') || '';
          if (/^ja/i.test(lang)) {
            const kind = u.searchParams.get('kind') || '';
            _cachedCaptions.push({ lang, kind, text: this.responseText });
          }
        } catch {}
      }
    });
  }
  return _OrigXHRSend.apply(this, args);
};

// Intercept fetch so we capture the /youtubei/v1/player response on SPA navigation
// and any timedtext that goes through fetch instead of XHR.
const _origFetch = window.fetch;
window.fetch = async function(input, init) {
  const url = typeof input === 'string' ? input : (input?.url || '');
  const resp = await _origFetch.apply(this, arguments);
  if (url.includes('/youtubei/v1/player')) {
    resp.clone().json().then(data => {
      // Always overwrite (even with []) — a video with no Japanese tracks
      // must clear out the previous video's, not keep showing them.
      _cachedJaTracks = _jaTracksFrom(data);
      _cachedCaptions = []; // clear stale captions from previous video
      _navigated = true;
    }).catch(() => {});
  }
  if (url.includes('api/timedtext')) {
    resp.clone().text().then(text => {
      if (text?.length > 0) {
        try {
          const u = new URL(url, location.href);
          const lang = u.searchParams.get('lang') || '';
          if (/^ja/i.test(lang)) {
            const kind = u.searchParams.get('kind') || '';
            _cachedCaptions.push({ lang, kind, text });
          }
        } catch {}
      }
    }).catch(() => {});
  }
  return resp;
};

// Handle fetch requests from the isolated-world content script.
// First checks _cachedCaptions (filled by player's XHR/fetch).
// If cache is empty, auto-triggers the YouTube player to load Japanese captions.
// Falls back to direct _origFetch (returns empty from extension context).
document.addEventListener('__mc_fetch_req', async (e) => {
  let req;
  try { req = JSON.parse(e.detail || '{}'); } catch { return; }
  const { url, reqId } = req;

  if (url.includes('api/timedtext')) {
    // If cache is empty, ask the player to load Japanese captions so our XHR
    // interceptor can catch the response. Remember previous state to restore it.
    if (_cachedCaptions.length === 0) {
      try {
        const player = document.querySelector('#movie_player');
        if (player && typeof player.setOption === 'function') {
          let prevTrack = null;
          try { prevTrack = player.getOption('captions', 'track'); } catch {}
          player.setOption('captions', 'track', { languageCode: 'ja' });
          await new Promise(resolve => {
            const poll = setInterval(() => {
              if (_cachedCaptions.length > 0) { clearInterval(poll); resolve(); }
            }, 150);
            setTimeout(() => { clearInterval(poll); resolve(); }, 3000);
          });
          // Restore previous caption state (hide if were hidden before)
          if (!prevTrack?.languageCode) {
            try { player.setOption('captions', 'track', {}); } catch {}
          } else if (prevTrack.languageCode !== 'ja') {
            try { player.setOption('captions', 'track', prevTrack); } catch {}
          }
        }
      } catch {}
    }

    if (_cachedCaptions.length > 0) {
      try {
        const u = new URL(url, location.href);
        const reqLang = (u.searchParams.get('lang') || '').toLowerCase();
        const reqKind = u.searchParams.get('kind') || '';
        const hit = _cachedCaptions.find(c => c.lang.toLowerCase() === reqLang && c.kind === reqKind)
                 || _cachedCaptions.find(c => /^ja/i.test(c.lang));
        if (hit) {
          document.dispatchEvent(new CustomEvent('__mc_fetch_res', {
            detail: JSON.stringify({ reqId, ok: true, status: 200, text: hit.text }),
          }));
          return;
        }
      } catch {}
    }
  }

  // Direct fetch fallback (returns empty from extension context but kept for completeness)
  let result;
  try {
    const r = await _origFetch(url);
    const text = await r.text();
    result = { reqId, ok: r.ok, status: r.status, text };
  } catch (err) {
    result = { reqId, ok: false, status: 0, text: '', error: err.message };
  }
  document.dispatchEvent(new CustomEvent('__mc_fetch_res', {
    detail: JSON.stringify(result),
  }));
});

// Respond to caption-track-list requests from the isolated-world content script.
document.addEventListener('__mc_get_ytpr', () => {
  let result;
  if (_navigated) {
    // Past the first video — window.ytInitialPlayerResponse/ytplayer.config
    // are stale leftovers from the hard page load, not this video.
    result = _cachedJaTracks || [];
  } else {
    const live = _jaTracksFrom(window.ytInitialPlayerResponse);
    const configTracks = _jaTracksFrom(window.ytplayer?.config);
    result = live.length ? live : (configTracks.length ? configTracks : (_cachedJaTracks || []));
  }

  document.dispatchEvent(new CustomEvent('__mc_ytpr_response', {
    detail: JSON.stringify(result),
  }));
});
