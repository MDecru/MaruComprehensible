// Hover mode — tokenizes transcript text into clickable word spans.
// Depends on: common.js (getTokenizer, getVocab, MM_CONTENT_POS, hasKanji)

var HOVER_JLPT_COLORS = { 5:'#ED7989', 4:'#FDC281', 3:'#72CE9D', 2:'#66AAE8', 1:'#7E69F0' };
var HOVER_JLPT_LABELS = { 1:'N1', 2:'N2', 3:'N3', 4:'N4', 5:'N5' };

var _hoverEnabled       = false;
var _hoverJlptMap       = null;
var _hoverJlptVocab     = null;
var _hoverVocab         = null;
var _hoverKanjiSet      = null;
var _hoverApprentice    = new Set();  // words at SRS level 1-4
var _hoverWordStatus    = new Map();  // word → {level, status}
var _hoverShowApprentice = false;     // toggle for apprentice highlighting
var _hoverConjHints      = false;     // toggle for conjugation/particle form hints
var _hoverTab            = 'dict';    // active tab in pinned card: 'dict' | 'grammar'
var _hoverTip        = null;
var _hoverPinned     = null;
var _hoverStyle      = null;
var _hoverDragging   = false;
var _hoverDragX      = 0;
var _hoverDragY      = 0;
var _hoverIsLight    = false;
var _lastTipDataset  = null;
var _lastTipDef      = undefined;

// If every kanji in a word is known, the word itself is readable
function _allKanjiKnown(word) {
  if (!_hoverKanjiSet || !_hoverKanjiSet.size) return false;
  var hasKanji = false;
  for (var i = 0; i < word.length; i++) {
    if (/[一-龯㐀-䶿]/.test(word[i])) {
      hasKanji = true;
      if (!_hoverKanjiSet.has(word[i])) return false;
    }
  }
  return hasKanji;
}

// Check if a compound word's stem is known (e.g. 勉強する when 勉強 is known)
function _stemKnown(word, vocab) {
  // する-verbs: noun+する, noun+される, noun+できる
  var suruMatch = word.match(/^(.+)(する|される|させる|できる|出来る|なさる|致す|いたす|为る|なさる)$/);
  if (suruMatch && vocab.has(suruMatch[1])) return true;
  // な-adjective + に/な/だ
  var naMatch = word.match(/^(.+)(に|な|だ)$/);
  if (naMatch && vocab.has(naMatch[1])) return true;
  // ている/てる form
  var teMatch = word.match(/^(.+)(ている|てる|でいる|でる)$/);
  if (teMatch && vocab.has(teMatch[1])) return true;
  return false;
}

// ── Init / teardown ──────────────────────────────────────────────────────────

// Lazily inject tooltip CSS + element (shared by hover mode and sidebar word clicks)
function _ensureHoverUI() {
  if (!_hoverStyle) {
    _hoverStyle = document.createElement('style');
    _hoverStyle.textContent = `
      .jp-tok { border-radius:2px; cursor:pointer; transition:background .1s; }
      .jp-tok:hover { background:rgba(114,206,157,.28) !important; outline:2px solid rgba(114,206,157,.55); box-shadow:0 0 6px rgba(114,206,157,.25); border-radius:3px; }
      .jp-tok-sel { background:rgba(114,206,157,.22) !important; outline:2px solid rgba(114,206,157,.6); }
      /* Highlighter-marker for the actual grammar particle (も/か/だけ/です…), not
         the whole content word it's attached to. box-shadow (not background) so
         it doesn't fight the subtitle's own black backdrop box. */
      .jp-gram-mark { border-radius:2px; cursor:pointer; transition:box-shadow .1s; }
      .jp-gram-mark:hover { box-shadow:inset 0 -0.34em 0 rgba(229,72,77,.6); }

      /* ── Dark theme (default) ── */
      #jp-hover-tip { position:fixed; z-index:2147483647; background:#232425; border:1px solid #363A3B;
        color:#c8d0e0; border-radius:14px; font-size:13px; line-height:1.4; width:260px;
        box-shadow:0 12px 40px rgba(0,0,0,.9); font-family:-apple-system,BlinkMacSystemFont,'Segoe UI Variable Text','Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;
        pointer-events:none; display:none; overflow:hidden; }
      #jp-hover-tip.pinned { pointer-events:auto; }
      #jp-hover-tip.pinned .jht-head { cursor:grab; }
      #jp-hover-tip.pinned .jht-head:active { cursor:grabbing; }
      .jht-head { display:flex; align-items:center; gap:8px; padding:10px 12px 8px;
        border-bottom:1px solid #363A3B; min-width:0; }
      .jht-word { font-size:20px; font-weight:700; color:#fff; letter-spacing:.02em;
        flex-shrink:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      .jht-right { display:flex; align-items:center; gap:6px; margin-left:auto; flex-shrink:0; }
      .jht-close { background:none; border:none; color:#555; font-size:16px; line-height:1; cursor:pointer; padding:0 2px; }
      .jht-close:hover { color:#fff; }
      .jht-reading-row { display:flex; align-items:center; justify-content:space-between; gap:8px; padding:5px 12px 2px; }
      .jht-reading { font-size:12px; color:#66AAE8; flex-shrink:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      .jht-conj { display:flex; flex-wrap:wrap; gap:4px; justify-content:flex-end; margin-left:auto; }
      .jht-conj-tag { font-size:10.5px; font-weight:700; color:#ffb0b0; background:rgba(229,72,77,.28);
        border:1px solid rgba(229,72,77,.55); border-radius:9px; padding:2px 8px; white-space:nowrap; cursor:help; }
      .jht-conj-tag.jht-conj-link { cursor:pointer; text-decoration:none; }
      .jht-conj-tag.jht-conj-link:hover { filter:brightness(1.15); }
      .jht-mmlv { font-size:10px; font-weight:700; padding:2px 6px; border-radius:5px; }
      .jht-mmlv.lv1,.jht-mmlv.lv2,.jht-mmlv.lv3,.jht-mmlv.lv4 { background:rgba(114,206,157,.2); color:#72CE9D; }
      .jht-mmlv.lv5,.jht-mmlv.lv6,.jht-mmlv.lv7,.jht-mmlv.lv8,.jht-mmlv.lv9 { background:rgba(102,170,232,.2); color:#66AAE8; }
      .jht-status { font-size:11px; font-weight:700; padding:2px 9px; border-radius:12px; white-space:nowrap; }
      .jht-status.known   { background:rgba(253,194,129,.18); color:#FDC281; }
      .jht-status.unknown { background:rgba(237,121,137,.15); color:#ED7989; }
      .jht-kanji { display:flex; flex-wrap:wrap; gap:5px; padding:7px 12px; }
      .jht-kc { display:flex; flex-direction:column; align-items:center; padding:5px 8px;
        border-radius:8px; border:1px solid rgba(114,206,157,.3); text-decoration:none;
        min-width:40px; transition:filter .12s; }
      .jht-kc:hover { background:rgba(114,206,157,.18); }
      .jht-kc.unknown:hover { background:rgba(237,121,137,.18); }
      .jht-kc.unknown { border-color:rgba(237,121,137,.3); }
      .jht-kc-ch { font-size:18px; font-weight:700; color:#72CE9D; line-height:1.2; }
      .jht-kc.unknown .jht-kc-ch { color:#ED7989; }
      .jht-kc-lv { font-size:10px; font-weight:600; color:#72CE9D; opacity:.8; margin-top:1px; }
      .jht-kc.unknown .jht-kc-lv { color:#ED7989; }
      .jht-footer { display:flex; flex-direction:column; gap:6px; padding:6px 12px 9px;
        border-top:1px solid #363A3B; }
      .jht-links { display:flex; gap:7px; justify-content:flex-end; }
      .jht-link { font-size:12px; font-weight:700; padding:4px 12px; border-radius:16px;
        text-decoration:none; color:#fff; border:1px solid transparent; transition:filter .12s; }
      .jht-link:hover { filter:brightness(.85); }
      .jht-jisho { background:#66AAE8; border-color:#66AAE8; }
      .jht-mm    { background:#FDC281; border-color:#FDC281; }
      .jht-set-known { background:none; border:1px solid rgba(237,121,137,.4); color:#ED7989;
        font-size:11px; font-weight:700; padding:3px 10px; border-radius:12px; cursor:pointer;
        transition:background .12s; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI Variable Text','Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif; flex-shrink:0; }
      .jht-set-known:hover { background:rgba(237,121,137,.12); }
      .jht-defs { padding:5px 12px 6px; border-bottom:1px solid #363A3B; }
      .jht-gloss { color:#dde2ee; font-size:13px; list-style:decimal; margin:0; padding-left:15px; }
      .jht-gloss li { margin-bottom:4px; line-height:1.4; }
      .jht-pos { font-size:10px; color:#8894b0; background:rgba(255,255,255,.07); border-radius:3px;
        padding:1px 5px; margin-left:6px; font-style:italic; vertical-align:middle;
        display:inline; white-space:nowrap; }
      .jht-loading  { font-size:11px; color:#555; font-style:italic; padding:2px 0; }
      .jht-no-entry { font-size:12px; color:#8890aa; padding-top:6px; padding-bottom:6px; }
      .jht-modebar { display:flex; gap:6px; padding:8px 12px; }
      .jht-modebtn { flex:1; border:none; border-radius:14px; padding:6px 0; font-size:12px;
        font-weight:700; color:#fff; cursor:pointer; opacity:.5; transition:opacity .15s,filter .15s;
        font-family:inherit; }
      .jht-modebtn:hover { opacity:.8; }
      .jht-modebtn.active { opacity:1; }
      .jht-modebtn-dict { background:#72CE9D; }
      .jht-modebtn-gram { background:#E5484D; }
      .jht-grammar { padding:8px 12px 14px; display:flex; flex-direction:column; gap:10px; }
      .jht-gitem { display:flex; flex-direction:column; align-items:flex-start; gap:3px; }
      .jht-gitem-desc { font-size:13px; color:#dde2ee; line-height:1.45; }

      /* ── Light theme ── */
      #jp-hover-tip.jht-light { background:#ffffff; border-color:#66AAE8; color:#3a3f47;
        box-shadow:0 8px 32px rgba(0,0,0,.18); }
      #jp-hover-tip.jht-light .jht-head { border-bottom-color:#e0e4f0; }
      #jp-hover-tip.jht-light .jht-word { color:#2c2f33; }
      #jp-hover-tip.jht-light .jht-close { color:#aab4c4; }
      #jp-hover-tip.jht-light .jht-close:hover { color:#66748a; }
      #jp-hover-tip.jht-light .jht-status.known   { background:rgba(253,194,129,.2); color:#b87a20; }
      #jp-hover-tip.jht-light .jht-status.unknown { background:rgba(237,121,137,.2); color:#b82d3e; }
      #jp-hover-tip.jht-light .jht-kc { border-color:rgba(114,206,157,.5); }
      #jp-hover-tip.jht-light .jht-kc.unknown { border-color:rgba(237,121,137,.4); }
      #jp-hover-tip.jht-light .jht-kc-ch { color:#1e7a4e; }
      #jp-hover-tip.jht-light .jht-kc.unknown .jht-kc-ch { color:#b82d3e; }
      #jp-hover-tip.jht-light .jht-kc-lv { color:#1e7a4e; }
      #jp-hover-tip.jht-light .jht-kc.unknown .jht-kc-lv { color:#b82d3e; }
      #jp-hover-tip.jht-light .jht-footer { border-top-color:#e0e4f0; }
      #jp-hover-tip.jht-light .jht-set-known { color:#b82d3e; border-color:rgba(237,121,137,.5); }
      #jp-hover-tip.jht-light .jht-defs { border-bottom-color:#e0e4f0; }
      #jp-hover-tip.jht-light .jht-gloss { color:#3a3f47; }
      #jp-hover-tip.jht-light .jht-pos { color:#66748a; background:rgba(0,0,0,.06); }
      #jp-hover-tip.jht-light .jht-conj-tag { color:#c0262b; background:rgba(229,72,77,.14); border-color:rgba(229,72,77,.4); }
      #jp-hover-tip.jht-light .jht-loading,
      #jp-hover-tip.jht-light .jht-no-entry { color:#8890aa; }
      #jp-hover-tip.jht-light .jht-gitem-desc { color:#3a3f47; }
    `;
    document.head.appendChild(_hoverStyle);
    // Read initial theme
    if (chrome.runtime?.id) {
      chrome.storage.local.get('light_theme', ({ light_theme }) => {
        if (chrome.runtime.lastError) return;
        _hoverIsLight = !!light_theme;
        if (_hoverTip) _hoverTip.classList.toggle('jht-light', _hoverIsLight);
      });
    }
  }
  if (!_hoverTip) {
    _hoverTip = document.createElement('div');
    _hoverTip.id = 'jp-hover-tip';
    _hoverTip.classList.toggle('jht-light', _hoverIsLight);
    document.body.appendChild(_hoverTip);
    // Hide full-hover (non-pinned) card when mouse leaves the tooltip
    _hoverTip.addEventListener('mouseleave', e => {
      if (_hoverPinned) return;
      if (e.relatedTarget?.closest?.('.jp-tok, .jp-gram-mark')) return;
      _hoverTip.style.display = 'none';
    });
  }
}

async function hoverEnable(findContainer) {
  if (_hoverEnabled) return { ok: true, msg: 'already on' };

  // Need tokenizer
  let tokenizer;
  try { tokenizer = await getTokenizer(); }
  catch (e) { return { ok: false, error: 'Tokenizer not ready — pre-load first' }; }

  // JLPT map
  if (!_hoverJlptMap) {
    try {
      const r = await fetch(chrome.runtime.getURL('data/jlpt_mapping.json'));
      const data = await r.json();
      _hoverJlptMap = {};
      for (const [lvl, ks] of Object.entries(data))
        for (const k of ks) _hoverJlptMap[k] = +lvl;
    } catch { _hoverJlptMap = {}; }
  }

  // Comprehensive JLPT vocab lookup (361k keys: Bunpro + kanji-derived + readings)
  if (!_hoverJlptVocab) {
    try {
      const r = await fetch(chrome.runtime.getURL('data/jlpt_vocab_lookup.json'));
      _hoverJlptVocab = await r.json();
    } catch { _hoverJlptVocab = {}; }
  }

  _hoverVocab = await getVocab();
  try { _hoverKanjiSet = await getKanji(); } catch { _hoverKanjiSet = new Set(); }
  try { _hoverApprentice = await getApprenticeVocab(); } catch {}
  try {
    _hoverWordStatus = await getWordStatusMap();
    chrome.storage.local.get(['mc_show_apprentice', 'mc_conj_hints'], (r) => {
      _hoverShowApprentice = r.mc_show_apprentice !== false;
      _hoverConjHints = r.mc_conj_hints !== false;
    });
  } catch {}

  // Find the transcript container
  const container = findContainer();
  if (!container) return { ok: false, error: 'No transcript found on page' };

  _ensureHoverUI();

  // Tokenize the container
  _hoverTokenizeElement(container, tokenizer);

  // Event listeners — capture phase ensures YouTube's SPA delegation can't block us
  document.addEventListener('mouseover',  _hoverOver,  { passive: true, capture: true });
  document.addEventListener('mouseout',   _hoverOut,   { passive: true, capture: true });
  document.addEventListener('click',      _hoverClick, true);
  document.addEventListener('keydown',    _hoverKey,   true);
  document.addEventListener('mousedown',  _hoverDragStart, true);
  document.addEventListener('mousemove',  _hoverDragMove, { passive: true });
  document.addEventListener('mouseup',    _hoverDragEnd);

  _hoverEnabled = true;
  return { ok: true };
}

// Activate hover event listeners immediately, without waiting for the tokenizer.
// Used by extension pages (e.g. video_history.html) that pre-create .jp-tok spans
// themselves so cards are interactive right away.
function hoverActivate() {
  if (_hoverEnabled) return;
  _ensureHoverUI();
  document.addEventListener('mouseover',  _hoverOver,  { passive: true, capture: true });
  document.addEventListener('mouseout',   _hoverOut,   { passive: true, capture: true });
  document.addEventListener('click',      _hoverClick, true);
  document.addEventListener('keydown',    _hoverKey,   true);
  document.addEventListener('mousedown',  _hoverDragStart, true);
  document.addEventListener('mousemove',  _hoverDragMove, { passive: true });
  document.addEventListener('mouseup',    _hoverDragEnd);
  _hoverEnabled = true;
  getVocab().then(v => { _hoverVocab = v; }).catch(() => {});
  getApprenticeVocab().then(s => { _hoverApprentice = s; }).catch(() => {});
  getWordStatusMap().then(m => { _hoverWordStatus = m; }).catch(() => {});
}

function hoverDisable() {
  if (!_hoverEnabled) return;
  _hoverEnabled = false;

  document.removeEventListener('mouseover',  _hoverOver,  { capture: true });
  document.removeEventListener('mouseout',   _hoverOut,   { capture: true });
  document.removeEventListener('click',      _hoverClick, true);
  document.removeEventListener('keydown',    _hoverKey,   true);

  _hoverHide();
  if (_hoverTip)   { _hoverTip.remove();   _hoverTip = null; }
  if (_hoverStyle) { _hoverStyle.remove(); _hoverStyle = null; }

  // Unwrap token spans, restoring original children (preserves <ruby> markup)
  for (const span of document.querySelectorAll('.jp-tok')) {
    span.replaceWith(...Array.from(span.childNodes));
  }
  // Clear processed markers so re-enabling re-tokenizes cleanly
  for (const el of document.querySelectorAll('[data-jp-done]')) {
    delete el.dataset.jpDone;
  }
}

// ── Tokenize DOM ─────────────────────────────────────────────────────────────

// Re-tokenize new content added to the DOM after hover was enabled
async function hoverRetokenize(root) {
  if (!_hoverEnabled || !root) return;
  const tokenizer = await getTokenizer().catch(() => null);
  if (!tokenizer) return;
  _hoverVocab = await getVocab(); // refresh in case it changed
  try { _hoverApprentice = await getApprenticeVocab(); } catch {}
  try { _hoverWordStatus = await getWordStatusMap(); } catch {}
  _hoverTokenizeElement(root, tokenizer);
}

// ── Tokenize DOM (ruby-aware) ─────────────────────────────────────────────────
//
// NJK pages use <ruby>漢字<rt>reading</rt></ruby> markup. A plain TreeWalker
// sees separate text nodes ("漢字" inside ruby, "reading" inside rt, trailing
// kana as a sibling) so cross-node merging is impossible.
//
// Instead we: (1) find "line containers" — elements that directly hold text /
// ruby children, (2) build a posMap of (textNode, offset) pairs that skips
// <rt>/<rp> content, (3) tokenize the cleaned string, (4) use DOM Ranges to
// wrap content tokens — a range can span the ruby→sibling boundary so the
// whole conjugated word becomes one .jp-tok span with the ruby preserved inside.

function _hoverTokenizeElement(root, tokenizer) {
  const containers = new Set();

  const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = tw.nextNode())) {
    if (n.parentElement?.closest('.jp-tok, #jp-hover-tip, rt, rp')) continue;
    if (!/[぀-鿿゠-ヿ]/.test(n.textContent)) continue;
    // If inside <ruby>, the container is ruby's parent; otherwise the direct parent
    let c = n.parentElement;
    if (c?.nodeName === 'RUBY') c = c.parentElement;
    if (c && c !== root) containers.add(c);
  }

  for (const c of containers) {
    if (!root.contains(c) || c.closest('.jp-tok, #jp-hover-tip')) continue;
    if (c.dataset.jpDone) continue;
    _hoverProcessContainer(c, tokenizer);
    c.dataset.jpDone = '1';
  }
}

// Build cleaned text + posMap (textNode/offset per char, skipping rt/rp).
function _hoverBuildPosMap(container) {
  const posMap = [];
  let text = '';

  function walk(el) {
    for (const child of el.childNodes) {
      if (child.nodeName === 'RT' || child.nodeName === 'RP') continue;
      if (child.nodeType === Node.TEXT_NODE) {
        for (let i = 0; i < child.textContent.length; i++) {
          posMap.push({ node: child, offset: i });
        }
        text += child.textContent;
      } else if (child.nodeType === Node.ELEMENT_NODE) {
        if (child.classList?.contains('jp-tok') || child.id === 'jp-hover-tip') continue;
        walk(child);
      }
    }
  }

  walk(container);
  return { text, posMap };
}

function _hoverProcessContainer(container, tokenizer) {
  const { text, posMap } = _hoverBuildPosMap(container);
  if (!text.trim() || !/[぀-鿿゠-ヿ]/.test(text)) return;

  const tokens = buildMergedTokens(tokenizer.tokenize(text), _hoverVocab);

  // Collect wraps in forward (left-to-right) order, apply in REVERSE — DOM
  // range extraction can split a shared text node, which would invalidate the
  // node/offset references of anything to its right if applied out of order.
  // Grammar-marker particles (も/か/だけ/です…) are pushed into the SAME array
  // (kind:'mark') interleaved in text order, rather than a separate list, so
  // that reverse-order invariant still holds across both kinds together.
  const toWrap = [];
  let pos = 0;

  for (const tok of tokens) {
    const surface = tok.surface_form;
    const start = pos, end = pos + surface.length;
    pos = end;
    if (end > posMap.length) break;
    // MM_TAGGABLE_POS (not MM_CONTENT_POS) so discourse connectors like そして
    // still get a hoverable span for their grammar tag, without affecting the
    // separate score%/known-word-count math in common.js.
    if (!MM_TAGGABLE_POS.has(tok.pos) || NUMERAL_RE.test(surface)) {
      // Grammar-marker particle: no known-word coloring of its own, just a
      // highlight-on-hover span so the mark lands on the actual particle
      // instead of underlining the whole content word it's attached to.
      // Hovering it opens the connected word's own hover card (via markTarget)
      // rather than a separate tooltip for the particle itself.
      if (_hoverConjHints && tok.markConj?.length) {
        const t = tok.markTarget;
        toWrap.push({
          kind: 'mark',
          sNode: posMap[start].node, sOff: posMap[start].offset,
          eNode: posMap[end-1].node, eOff: posMap[end-1].offset + 1,
          surface: surface,
          target: t ? { word: t.surface_form, basic: t.basic_form, pos: t.pos, reading: t.reading, conj: t.conj } : null,
        });
      }
      continue;
    }

    const basic = tok.basic_form || surface;
    // Determine JLPT level: Bunpro vocab list first, fallback to hardest kanji
    let level = _hoverJlptVocab?.[basic] || 0;
    if (!level) {
      for (const ch of basic) {
        const l = _hoverJlptMap?.[ch];
        if (l && (level === 0 || l < level)) level = l;
      }
    }
    toWrap.push({
      kind: 'word',
      sNode: posMap[start].node,   sOff: posMap[start].offset,
      eNode: posMap[end-1].node,   eOff: posMap[end-1].offset + 1,
      surface, basic, level,
      pos:     tok.pos,
      reading: tok.reading || '',
      conj:    tok.conj || [],
      known:   _hoverVocab.has(basic) || _hoverVocab.has(surface) || _allKanjiKnown(basic) || _stemKnown(basic, _hoverVocab) || _stemKnown(surface, _hoverVocab),
      apprentice: _hoverShowApprentice && (_hoverApprentice.has(basic) || _hoverApprentice.has(surface)),
      status:  _hoverWordStatus.get(basic) || _hoverWordStatus.get(surface) || null,
    });
  }

  for (let i = toWrap.length - 1; i >= 0; i--) {
    const w = toWrap[i];
    try {
      const range = document.createRange();
      range.setStart(w.sNode, w.sOff);
      range.setEnd(w.eNode, w.eOff);

      const span = document.createElement('span');

      if (w.kind === 'mark') {
        // Grammar-marker particle: highlight-on-hover only, no coloring of its
        // own. If it's linked to a content word, hovering/clicking it opens
        // that word's normal hover card (see _hoverOver/_hoverClick) instead
        // of a separate tooltip for the particle itself.
        span.className = 'jp-gram-mark';
        // Store the particle's own text so the tooltip can show "particle → word"
        span.dataset.particle = w.surface || '';
        if (w.target) {
          span.dataset.word    = w.target.word;
          span.dataset.basic   = w.target.basic;
          span.dataset.pos     = w.target.pos;
          span.dataset.reading = w.target.reading;
          if (w.target.conj?.length) span.dataset.conj = w.target.conj.join('|');
        }
      } else {
        span.className       = 'jp-tok';
        span.dataset.word    = w.surface;
        span.dataset.basic   = w.basic;
        span.dataset.pos     = w.pos;
        span.dataset.reading = w.reading;
        if (w.conj.length) span.dataset.conj = w.conj.join('|');
        if (w.status) {
          span.dataset.mmLevel  = w.status.level ?? '';
          span.dataset.mmStatus = w.status.status ?? '';
        }
        span.style.color     = w.known
          ? (_hoverIsLight ? '#1a5fa8' : '#66AAE8')
          : w.apprentice
            ? (_hoverIsLight ? '#2d8a5e' : '#72CE9D')
            : (_hoverIsLight ? '#b82d3e' : '#ED7989');
      }

      // extractContents handles ruby-boundary ranges — ruby markup stays inside span
      span.appendChild(range.extractContents());
      range.insertNode(span);
    } catch { /* ignore invalid ranges */ }
  }
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function _katToHira(s) {
  return (s || '').replace(/[ァ-ン]/g, c => String.fromCharCode(c.charCodeAt(0) - 0x60));
}

var _defCache = {};
async function _fetchDef(word) {
  if (_defCache[word] !== undefined) return _defCache[word];
  if (!chrome.runtime?.id) return null;
  try {
    const resp = await chrome.runtime.sendMessage({ action: 'jishoLookup', word });
    if (!resp?.ok) { _defCache[word] = null; return null; }
    _defCache[word] = { reading: resp.reading, senses: resp.senses };
    return _defCache[word];
  } catch { _defCache[word] = null; return null; }
}

// ── Tooltip content ──────────────────────────────────────────────────────────

// ── Furigana ──────────────────────────────────────────────────────────────────

var _furiganaStyleEl = null;
function hoverApplyFurigana(container) {
  if (!_furiganaStyleEl) {
    _furiganaStyleEl = document.createElement('style');
    _furiganaStyleEl.textContent = 'ruby{ruby-align:center}rt{pointer-events:none;user-select:none;opacity:var(--mc-rt-opacity,1)}';
    document.head.appendChild(_furiganaStyleEl);
  }
  for (const span of [...container.querySelectorAll('.jp-tok')]) {
    const reading = span.dataset.reading;
    if (!reading) continue;
    const text = span.dataset.basic || span.dataset.word || '';
    if (!hasKanji(text)) continue;
    const hira = _katToHira(reading);
    if (hira === text) continue;
    const ruby = document.createElement('ruby');
    span.before(ruby);
    ruby.appendChild(span);
    const rt = document.createElement('rt');
    rt.textContent = hira;
    ruby.appendChild(rt);
  }
}

function _wireHoverTipButtons() {
  _hoverTip.querySelector('.jht-close')?.addEventListener('click', _hoverHide);
  _hoverTip.querySelectorAll('.jht-modebtn').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      _hoverTab = btn.dataset.tab;
      if (_lastTipDataset) {
        _hoverTip.innerHTML = _hoverBuildTip(_lastTipDataset, true, _lastTipDef);
        _wireHoverTipButtons();
      }
    });
  });
  _hoverTip.querySelector('.jht-set-known')?.addEventListener('click', async e => {
    e.stopPropagation();
    const basic = e.currentTarget.dataset.basic || e.currentTarget.dataset.word;
    if (!basic || !chrome.runtime?.id) return;
    const { mc_user_known = [] } = await chrome.storage.local.get('mc_user_known');
    if (!mc_user_known.includes(basic)) {
      mc_user_known.push(basic);
      await chrome.storage.local.set({ mc_user_known });
    }
    _hoverVocab?.add(basic);
    // Re-render tooltip showing word as now known
    if (_lastTipDataset) {
      _hoverTip.innerHTML = _hoverBuildTip(_lastTipDataset, true, _lastTipDef ?? null);
      _wireHoverTipButtons();
    }
    // Re-color transcript spans immediately
    for (const span of document.querySelectorAll('.jp-tok')) {
      if (span.dataset.basic === basic || span.dataset.word === basic) {
        span.style.color = '#66AAE8';
        span.style.display = '';
      }
    }
    // Let content scripts re-color subtitle overlays with their own settings
    document.dispatchEvent(new CustomEvent('mc-word-marked-known', { detail: { word: basic } }));
  });
}

function _hoverBuildTip(dataset, pinned, defResult) {
  const word  = dataset.word  || '';
  const basic = dataset.basic || word;
  const pos   = dataset.pos   || '';
  const kReading = _katToHira(dataset.reading || '');

  const known = _hoverVocab?.has(basic) || _hoverVocab?.has(word);
  const isAppr = (typeof _hoverApprentice !== 'undefined') && (_hoverApprentice.has(basic) || _hoverApprentice.has(word));

  // Level badge from MaruMori API
  const mmLevel = dataset.mmLevel || '';
  const mmStatus = dataset.mmStatus || '';
  const mmLvClass = mmLevel ? ` lv${_esc(mmLevel)}` : '';
  const mmBadge = mmLevel
    ? `<span class="jht-mmlv${mmLvClass}">Lv${_esc(mmLevel)}</span>` : '';

  // Status: only show "Known" for known. Pipeline/apprentice shows nothing.
  const statusLabel = known ? '✓ Known' : '';
  const statusHtml = (pos && statusLabel)
    ? `<span class="jht-status known">${statusLabel}</span>`
    : '';

  const closeBtn = pinned ? `<button class="jht-close" title="Close">×</button>` : '';
  const particle = dataset.particle || '';
  const headWord = particle ? `${_esc(word)} <span style="font-size:13px;color:#8890aa;font-weight:400">+</span> ${_esc(particle)}` : _esc(word);
  const headHtml = `<div class="jht-head"><span class="jht-word">${headWord}</span><div class="jht-right">${mmBadge}${statusHtml}${closeBtn}</div></div>`;

  // Reading line: prefer Jisho reading (hiragana), fallback to kuromoji
  const displayReading = defResult?.reading || kReading;
  const readingText = (displayReading && displayReading !== word) ? _esc(displayReading) : '';

  // Conjugation/particle form hints (verb/adjective conjugation, noun case role)
  const conjTags = (_hoverConjHints && dataset.conj) ? dataset.conj.split('|').filter(Boolean) : [];
  const hasGrammar = conjTags.length > 0;

  // Quick (unpinned) hover: small glance chips, no tabs (nothing to click while unpinned).
  // Pinned: tags move into the Grammar tab below, with room for a full explanation each.
  const conjChipsHtml = (!pinned && hasGrammar)
    ? `<div class="jht-conj">${conjTags.map(t => `<span class="jht-conj-tag">${_esc(t)}</span>`).join('')}</div>`
    : '';

  const readingHtml = (readingText || conjChipsHtml)
    ? `<div class="jht-reading-row"><span class="jht-reading">${readingText}</span>${conjChipsHtml}</div>`
    : '';

  const showTabs = pinned && hasGrammar;
  const activeTab = showTabs ? _hoverTab : 'dict';
  const tabsHtml = showTabs
    ? `<div class="jht-modebar">
        <button class="jht-modebtn jht-modebtn-dict${activeTab === 'dict' ? ' active' : ''}" data-tab="dict">Translation</button>
        <button class="jht-modebtn jht-modebtn-gram${activeTab === 'grammar' ? ' active' : ''}" data-tab="grammar">Grammar</button>
      </div>`
    : '';

  const grammarHtml = `<div class="jht-grammar">${particle ? `<div style="font-size:11px;color:#8890aa;margin-bottom:2px">Attached to: ${_esc(word)} <b style="color:var(--text, #c8d0e0)">+ ${_esc(particle)}</b></div>` : ''}${conjTags.map(t => {
    const mmQuery = CONJ_LABEL_TO_SURFACE[t] || t;
    const mmUrl = `https://marumori.io/grammar?q=${encodeURIComponent(mmQuery)}`;
    return `
    <div class="jht-gitem">
      <a class="jht-conj-tag jht-conj-link" href="${mmUrl}" target="_blank" title="Look up on MaruMori">${_esc(t)}</a>
      <span class="jht-gitem-desc">${_esc(CONJ_TAG_INFO[t] || '')}</span>
    </div>`;
  }).join('')}</div>`;

  // Definitions (from Jisho, or loading placeholder)
  let defHtml = '';
  if (pinned) {
    if (defResult === undefined) {
      // Still loading
      defHtml = `<div class="jht-defs"><span class="jht-loading">Loading…</span></div>`;
    } else if (defResult?.senses?.length) {
      const items = defResult.senses.map(s => {
        const short = s.pos ? _shortenPos(s.pos) : null;
        const posTag = short ? `<span class="jht-pos">${_esc(short)}</span>` : '';
        return `<li>${s.defs.map(_esc).join('; ')}${posTag}</li>`;
      }).join('');
      defHtml = `<div class="jht-defs"><ul class="jht-gloss">${items}</ul></div>`;
    } else if (defResult === null) {
      defHtml = `<div class="jht-defs jht-no-entry">No definition found</div>`;
    }
  }

  // Per-kanji cards
  const kanjiChars = [...basic].filter(ch => /[一-龯㐀-䶿]/.test(ch));
  const kanjiHtml = kanjiChars.length
    ? `<div class="jht-kanji">${kanjiChars.map(ch => {
        const kknown = _hoverVocab?.has(ch);
        const jlvl   = _hoverJlptMap?.[ch];
        const lvlLbl = jlvl ? HOVER_JLPT_LABELS[jlvl] : (kknown ? '✓' : '?');
        const lvlStyle = jlvl ? `color:${HOVER_JLPT_COLORS[jlvl]}` : '';
        const mmUrl = `https://marumori.io/dictionary/search?q=${encodeURIComponent(ch)}&t=kanji`;
        return `<a class="jht-kc${kknown ? '' : ' unknown'}" href="${mmUrl}" target="_blank">
          <span class="jht-kc-ch">${_esc(ch)}</span>
          <span class="jht-kc-lv" style="${lvlStyle}">${lvlLbl}</span>
        </a>`;
      }).join('')}</div>` : '';

  const isGrammarTab = showTabs && activeTab === 'grammar';
  const bodyHtml = isGrammarTab ? grammarHtml : (defHtml + kanjiHtml);

  // Set as Known / Jisho / MaruMori all act on the WORD's dictionary entry —
  // meaningless on the Grammar pane (which is about the attached particle,
  // not the word's own vocab status), so skip the footer there entirely.
  let footerHtml = '';
  if (!isGrammarTab) {
    const displayWord = basic !== word ? basic : word;
    const setKnownBtn = (pinned && !known && pos)
      ? `<button class="jht-set-known" data-basic="${_esc(basic)}" data-word="${_esc(word)}">+ Set as Known</button>`
      : '';
    const linksHtml = `<div class="jht-links">
      <a class="jht-link jht-jisho" href="https://jisho.org/search/${encodeURIComponent(displayWord)}" target="_blank">Jisho ↗</a>
      <a class="jht-link jht-mm" href="https://marumori.io/dictionary/search?q=${encodeURIComponent(displayWord)}&t=vocabulary" target="_blank">MaruMori ↗</a>
    </div>`;
    footerHtml = `<div class="jht-footer">${setKnownBtn}${linksHtml}</div>`;
  }

  return headHtml + readingHtml + tabsHtml + bodyHtml + footerHtml;
}

function _esc(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

var _POS_MAP = [
  [/godan verb.*irregular/i,       'Godan verb (irr.)'],
  [/godan verb/i,                  'Godan verb'],
  [/ichidan verb.*irregular/i,     'Ichidan verb (irr.)'],
  [/ichidan verb/i,                'Ichidan verb'],
  [/na-adjective|keiyodoshi/i,     'na-adj.'],
  [/i-adjective|keiyoshi/i,        'i-adj.'],
  [/adverb.*to$/i,                 'Adverb (to)'],
  [/adverb/i,                      'Adverb'],
  [/auxiliary verb/i,              'Aux. verb'],
  [/auxiliary/i,                   'Auxiliary'],
  [/conjunction/i,                 'Conj.'],
  [/interjection/i,                'Interj.'],
  [/wikipedia/i,                   null],
  [/^noun/i,                       'Noun'],
  [/^particle$/i,                  'Particle'],
  [/^prefix$/i,                    'Prefix'],
  [/^suffix$/i,                    'Suffix'],
];

function _shortenPos(pos) {
  for (const [re, label] of _POS_MAP) {
    if (re.test(pos)) return label;
  }
  // Fallback: cap at 20 chars
  return pos.length > 20 ? pos.slice(0, 18) + '…' : pos;
}

// ── Positioning ──────────────────────────────────────────────────────────────

function _hoverPosition(el) {
  const rect = el.getBoundingClientRect();
  const tw   = _hoverTip.offsetWidth  || 280;
  const th   = _hoverTip.offsetHeight || 120;
  let x = rect.left;
  // Prefer above; fall back to below if not enough room
  let y = rect.top - th - 22;
  if (y < 8) y = rect.bottom + 8;
  if (x + tw > window.innerWidth  - 8) x = window.innerWidth  - tw - 8;
  if (x < 8) x = 8;
  _hoverTip.style.left = x + 'px';
  _hoverTip.style.top  = y + 'px';
}

// ── Event handlers ───────────────────────────────────────────────────────────

function _hoverOver(e) {
  if (_hoverPinned || !_hoverTip) return;
  if (e.target.closest('#jp-hover-tip')) return; // mouse moved into tooltip, keep it
  const tok = e.target.closest('.jp-tok, .jp-gram-mark');
  if (!tok || !tok.dataset.word) { _hoverTip.style.display = 'none'; return; }

  const full = !!tok.closest('[data-mc-full-hover]');
  if (_lastTipDataset !== tok.dataset) _hoverTab = tok.classList.contains('jp-gram-mark') ? 'grammar' : 'dict';
  _lastTipDataset = tok.dataset; _lastTipDef = undefined;
  _hoverTip.innerHTML = _hoverBuildTip(tok.dataset, full, full ? undefined : null);
  _hoverTip.style.display = 'block';
  _hoverTip.classList.remove('pinned');
  _hoverTip.style.pointerEvents = full ? 'auto' : 'none';
  _hoverPosition(tok);
  if (full) {
    _wireHoverTipButtons();
    _fetchDef(tok.dataset.basic || tok.dataset.word).then(def => {
      // _hoverTip may be gone if hover mode was disabled while the fetch was in flight
      if (!_hoverTip || _hoverTip.style.display === 'none' || _lastTipDataset !== tok.dataset) return;
      _lastTipDef = def;
      _hoverTip.innerHTML = _hoverBuildTip(tok.dataset, true, def);
      _hoverPosition(tok);
      _wireHoverTipButtons();
    });
  }
}

function _hoverOut(e) {
  if (_hoverPinned || !_hoverTip) return;
  if (e.relatedTarget?.closest?.('.jp-tok, .jp-gram-mark')) return;
  if (e.relatedTarget?.closest?.('#jp-hover-tip')) return; // going into tooltip
  _hoverTip.style.display = 'none';
}

function _hoverClick(e) {
  if (!_hoverTip) return;
  const tok = e.target.closest('.jp-tok, .jp-gram-mark');
  if (tok && tok.dataset.word) {
    e.stopPropagation();
    if (_hoverPinned === tok) { _hoverHide(); return; }
    if (_hoverPinned) _hoverPinned.classList.remove('jp-tok-sel');

    // Show immediately with loading placeholder for definitions. Clicking the
    // grammar-marker particle itself (も/か/です…) opens straight to the
    // Grammar pane instead of defaulting to Dict.
    _hoverTab = tok.classList.contains('jp-gram-mark') ? 'grammar' : 'dict';
    _lastTipDataset = tok.dataset; _lastTipDef = undefined;
    _hoverTip.innerHTML = _hoverBuildTip(tok.dataset, true, undefined);
    _hoverTip.style.display = 'block';
    _hoverTip.classList.add('pinned');
    _hoverTip.style.pointerEvents = 'auto';
    _hoverPosition(tok);
    _hoverPinned = tok;
    tok.classList.add('jp-tok-sel');
    _wireHoverTipButtons();
    // Notify content scripts that a word was pinned — lets them re-pause if the
    // site player called video.play() in its own click handler before ours ran
    document.dispatchEvent(new CustomEvent('mc-word-pinned'));

    // Fetch definition then re-render in place
    const lookupWord = tok.dataset.basic || tok.dataset.word;
    _fetchDef(lookupWord).then(def => {
      if (!_hoverTip || _hoverPinned !== tok) return; // user moved on / hover disabled
      _lastTipDef = def;
      _hoverTip.innerHTML = _hoverBuildTip(tok.dataset, true, def);
      _hoverPosition(tok);
      _wireHoverTipButtons();
    });
    return;
  }
  if (_hoverPinned && !e.target.closest('#jp-hover-tip')) _hoverHide();
}

function _hoverDragStart(e) {
  if (!_hoverPinned || !_hoverTip || e.button !== 0) return;
  if (!e.target.closest('.jht-head')) return;
  _hoverDragging = true;
  _hoverDragX = e.clientX - _hoverTip.offsetLeft;
  _hoverDragY = e.clientY - _hoverTip.offsetTop;
}

function _hoverDragMove(e) {
  if (!_hoverDragging) return;
  var x = e.clientX - _hoverDragX;
  var y = e.clientY - _hoverDragY;
  if (x < 0) x = 0;
  if (y < 0) y = 0;
  if (x + _hoverTip.offsetWidth  > window.innerWidth)  x = window.innerWidth  - _hoverTip.offsetWidth;
  if (y + _hoverTip.offsetHeight > window.innerHeight) y = window.innerHeight - _hoverTip.offsetHeight;
  _hoverTip.style.left = x + 'px';
  _hoverTip.style.top  = y + 'px';
}

function _hoverDragEnd(e) {
  _hoverDragging = false;
}

function _hoverKey(e) {
  if (e.key === 'Escape') _hoverHide();
}

function _hoverHide() {
  if (!_hoverTip) return;
  _hoverTip.style.display = 'none';
  _hoverTip.classList.remove('pinned');
  _hoverTip.style.pointerEvents = 'none';
  if (_hoverPinned) { _hoverPinned.classList.remove('jp-tok-sel'); _hoverPinned = null; }
  document.dispatchEvent(new CustomEvent('mc-tooltip-closed'));
}

// ── Public API for sidebar ────────────────────────────────────────────────────

var _sbOutsideActive = false;

// Show a pinned hover tooltip for a word entry in the sidebar.
// Works whether hover mode is active or not.
async function hoverShowWord(wordData, anchorEl) {
  _ensureHoverUI();
  if (!_hoverVocab) _hoverVocab = await getVocab();

  // Clear previous pinned state (may be a jp-tok span or a previous sb-word sentinel)
  if (_hoverPinned) { _hoverPinned.classList.remove('jp-tok-sel'); _hoverPinned = null; }

  const dataset = {
    word:    wordData.basic,
    basic:   wordData.basic,
    pos:     '',
    reading: wordData.reading || '',
  };

  _hoverTab = 'dict';
  _lastTipDataset = dataset; _lastTipDef = undefined;
  _hoverTip.innerHTML = _hoverBuildTip(dataset, true, undefined);
  _hoverTip.style.display = 'block';
  _hoverTip.classList.add('pinned');
  _hoverTip.style.pointerEvents = 'auto';

  // Use anchorEl as a sentinel so _hoverOut (if hover mode is on) sees a truthy
  // _hoverPinned and returns early — otherwise mousing over the tooltip closes it.
  _hoverPinned = anchorEl;

  _sbPosition(anchorEl);
  _wireHoverTipButtons();

  // When hover mode is off its document listeners aren't registered, so add
  // click-outside and Escape handling ourselves.
  if (!_hoverEnabled) _sbEnsureOutsideListeners();

  _fetchDef(dataset.basic).then(def => {
    if (!_hoverTip || _hoverTip.style.display === 'none') return;
    _lastTipDef = def;
    _hoverTip.innerHTML = _hoverBuildTip(dataset, true, def);
    _sbPosition(anchorEl);
    _wireHoverTipButtons();
  });
}

function _sbEnsureOutsideListeners() {
  if (_sbOutsideActive) return;
  _sbOutsideActive = true;

  const onKey = (e) => { if (e.key === 'Escape') { _hoverHide(); cleanup(); } };
  const onClick = (e) => {
    // Clicking another sb-word is handled by the sidebar delegation — just clean up listeners
    if (e.target.closest('.sb-word')) { cleanup(); return; }
    if (!e.target.closest('#jp-hover-tip')) { _hoverHide(); cleanup(); }
  };
  const cleanup = () => {
    document.removeEventListener('click',   onClick, true);
    document.removeEventListener('keydown', onKey,   true);
    _sbOutsideActive = false;
  };

  // Defer so this click event doesn't immediately close the tooltip
  setTimeout(() => {
    document.addEventListener('click',   onClick, true);
    document.addEventListener('keydown', onKey,   true);
  }, 0);
}

// Position tooltip to the left of the sidebar panel
function _sbPosition(anchorEl) {
  const tipW = _hoverTip.offsetWidth  || 270;
  const tipH = _hoverTip.offsetHeight || 150;
  const rect = anchorEl.getBoundingClientRect();
  const x    = Math.max(8, rect.left - tipW - 8);
  let   y    = rect.top;
  if (y + tipH > window.innerHeight - 8) y = window.innerHeight - tipH - 8;
  if (y < 8) y = 8;
  _hoverTip.style.left = x + 'px';
  _hoverTip.style.top  = y + 'px';
}

// Live theme switching
try { chrome.storage.onChanged.addListener((changes, area) => {
  if (!chrome.runtime?.id) return;
  if (area === 'local' && 'light_theme' in changes) {
    _hoverIsLight = !!changes.light_theme.newValue;
    if (_hoverTip) _hoverTip.classList.toggle('jht-light', _hoverIsLight);
  }
  if (changes.mc_show_apprentice) {
    _hoverShowApprentice = !!changes.mc_show_apprentice.newValue;
  }
  if (changes.mc_conj_hints) {
    _hoverConjHints = !!changes.mc_conj_hints.newValue;
  }
}); } catch {}
